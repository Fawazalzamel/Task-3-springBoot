package com.CheckYourUnderstanding.Task2.util.enums;

public enum Status {
      ACTIVE, INACTIVE
}
