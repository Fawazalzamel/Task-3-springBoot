package com.CheckYourUnderstanding.Task2.entity;

import javax.persistence.*;

@Entity
@Table(name="user_settings")
public class UserSettingsEntity {
    @Id
    @Column(name="id",nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    private boolean receiveNewLetter;

    private String preferredLanguage;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isReceiveNewLetter() {
        return receiveNewLetter;
    }

    public void setReceiveNewLetter(boolean receiveNewLetter) {
        this.receiveNewLetter = receiveNewLetter;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;



    }
    @OneToOne
    @JoinColumn(name = "user_id")
    private UserEntity user;

}
